def spotify_top_playlists():
    playlists = {'Top_50_USA':'spotify:playlist:37i9dQZEVXbLRQDuF5jeBp',
                 'Viral_50_USA': 'spotify:playlist:37i9dQZEVXbKuaTI1Z1Afx'}
    return playlists

def spotify_new_playlists():
    playlists = {'Pop_New_Music': 'spotify:playlist:37i9dQZF1DX4JAvHpjipBk',
                 'Hip_Hop_New_Music':'spotify:playlist:37i9dQZF1DX4SrOBCjlfVi',
                 'Country_New_Music':'spotify:playlist:37i9dQZF1DWVn8zvR5ROMB'}
    return playlists